package com.sukisu.ultra.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class Module(
    val id: String,
    val name: String,
    val author: String,
    val version: String,
    val versionCode: Long,
    val description: String,
    val enabled: Boolean,
    val update: Boolean,
    val remove: Boolean,
    val updateJson: String,
    val hasWebUi: Boolean,
    val hasActionScript: Boolean,
    val metamodule: Boolean,
    val zygisk: Boolean = false,
    val actionIconPath: String?,
    val webUiIconPath: String?,
    // preinit state for the next boot: "", "ok", "no_space", "error" or "bootloop"
    val preinit: String = "",
    val bannerPath: String? = null,
)
