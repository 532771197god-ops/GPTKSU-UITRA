package com.sukisu.ultra.ui.screen.gptchat

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

internal data class GptReply(val text: String, val responseId: String)

internal object OpenAiResponsesClient {
    private val http = OkHttpClient.Builder()
        .callTimeout(90, TimeUnit.SECONDS)
        .build()

    fun send(apiKey: String, prompt: String, previousResponseId: String?): GptReply {
        val payload = JSONObject()
            .put("model", "gpt-6-luna")
            .put("store", true)
            .put("instructions", "You are GPTKSU Ultra's optional support assistant. Give cautious Android and kernel troubleshooting advice. Never claim to have run commands or changed the device. Do not ask the app to execute commands; the user must review any shell commands manually. Ask for device details only when needed and remind the user not to share passwords, tokens, or personal data.")
            .put("input", prompt)
        if (!previousResponseId.isNullOrBlank()) payload.put("previous_response_id", previousResponseId)

        val request = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .header("Authorization", "Bearer $apiKey")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(body).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IOException(detail?.takeIf { it.isNotBlank() } ?: "OpenAI API request failed (${response.code})")
            }
            val json = JSONObject(body)
            val output = json.optJSONArray("output") ?: throw IOException("The API response did not include output.")
            val text = buildString {
                for (index in 0 until output.length()) {
                    val item = output.optJSONObject(index) ?: continue
                    val content = item.optJSONArray("content") ?: continue
                    for (partIndex in 0 until content.length()) {
                        val part = content.optJSONObject(partIndex) ?: continue
                        if (part.optString("type") == "output_text") {
                            if (isNotEmpty()) append('\n')
                            append(part.optString("text"))
                        }
                    }
                }
            }.trim()
            if (text.isBlank()) throw IOException("The API returned no text. Try sending your message again.")
            return GptReply(text, json.optString("id"))
        }
    }
}
