package com.sukisu.ultra.ui.screen.gptchat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.sukisu.ultra.R
import com.sukisu.ultra.ui.navigation3.LocalNavigator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class ChatLine(val fromUser: Boolean, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GptChatScreen() {
    val context = LocalContext.current
    val navigator = LocalNavigator.current
    val scope = rememberCoroutineScope()
    val keyStore = remember(context) { OpenAiApiKeyStore(context.applicationContext) }
    val messages = remember { mutableStateListOf<ChatLine>() }
    val listState = rememberLazyListState()
    var apiKey by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var previousResponseId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(keyStore) { apiKey = withContext(Dispatchers.IO) { keyStore.load().orEmpty() } }
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.gpt_chat_title)) },
                navigationIcon = { TextButton(onClick = { navigator.pop() }) { Text(stringResource(R.string.log_viewer_back)) } },
                actions = {
                    TextButton(onClick = {
                        messages.clear()
                        previousResponseId = null
                        status = null
                    }, enabled = messages.isNotEmpty() && !busy) { Text(stringResource(R.string.gpt_chat_new)) }
                }
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier.fillMaxWidth().imePadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it.trim() },
                        modifier = Modifier.weight(1f),
                        label = { Text(stringResource(R.string.gpt_chat_api_key)) },
                        placeholder = { Text("sk-…") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, keyboardType = KeyboardType.Password),
                        enabled = !busy
                    )
                    TextButton(
                        onClick = {
                            scope.launch(Dispatchers.IO) {
                                if (apiKey.isBlank()) keyStore.clear() else keyStore.save(apiKey)
                            }
                            status = context.getString(if (apiKey.isBlank()) R.string.gpt_chat_key_removed else R.string.gpt_chat_key_saved)
                        },
                        enabled = !busy
                    ) { Text(stringResource(R.string.gpt_chat_save_key)) }
                }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.gpt_chat_message)) },
                    minLines = 1,
                    maxLines = 4,
                    enabled = !busy
                )
                Button(
                    onClick = {
                        val prompt = input.trim()
                        val key = apiKey.trim()
                        if (key.isBlank()) {
                            status = context.getString(R.string.gpt_chat_key_required)
                        } else if (prompt.isNotBlank()) {
                            messages.add(ChatLine(true, prompt))
                            input = ""
                            status = null
                            busy = true
                            scope.launch {
                                try {
                                    val reply = withContext(Dispatchers.IO) {
                                        OpenAiResponsesClient.send(key, prompt, previousResponseId)
                                    }
                                    previousResponseId = reply.responseId
                                    messages.add(ChatLine(false, reply.text))
                                } catch (e: Exception) {
                                    status = e.message ?: context.getString(R.string.gpt_chat_failed)
                                } finally {
                                    busy = false
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && input.isNotBlank()
                ) {
                    Icon(Icons.Rounded.Chat, contentDescription = null)
                    Text("  " + stringResource(if (busy) R.string.gpt_chat_sending else R.string.gpt_chat_send))
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Text(
                text = stringResource(R.string.gpt_chat_privacy),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
            status?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                        Card(
                            modifier = Modifier.fillMaxWidth(0.88f),
                            shape = RoundedCornerShape(18.dp),
                            colors = androidx.compose.material3.CardDefaults.cardColors(
                                containerColor = if (line.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                        ) {
                            Text(
                                text = line.text,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                color = if (line.fromUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
